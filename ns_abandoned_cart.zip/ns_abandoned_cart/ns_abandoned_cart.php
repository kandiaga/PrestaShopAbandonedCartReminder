<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once(dirname(__FILE__) . '/classes/AbandonedCart.php');

class Ns_Abandoned_Cart extends Module
{
    public function __construct()
    {
        $this->name = 'ns_abandoned_cart';
        $this->tab = 'administration';
        $this->version = '1.0.0';
        $this->author = 'NdiagaSoft';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Abandoned Cart Reminder');
        $this->description = $this->l('Send reminder emails to customers with abandoned carts.');
        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);
    }

    public function install()
    {
        if (!parent::install()) {
            return false;
        }

        if (!$this->registerHook('actionCartSave')) {
            $this->_errors[] = $this->l('Failed to register actionCartSave hook.');
            return false;
        }

        if (!$this->registerHook('displayBackOfficeHeader')) {
            $this->_errors[] = $this->l('Failed to register displayBackOfficeHeader hook.');
            return false;
        }

        if (!$this->createDatabaseTable()) {
            $this->_errors[] = $this->l('Failed to create database table.');
            return false;
        }

        if (!$this->installTab()) {
            $this->_errors[] = $this->l('Failed to install admin tab.');
            return false;
        }

        if (!$this->createConfig()) {
            $this->_errors[] = $this->l('Failed to create configuration.');
            return false;
        }

        return true;
    }

    public function uninstall()
    {
        if (!parent::uninstall()) {
            return false;
        }

        if (!$this->unregisterHook('actionCartSave')) {
            return false;
        }

        if (!$this->unregisterHook('displayBackOfficeHeader')) {
            return false;
        }

        if (!$this->dropDatabaseTable()) {
            return false;
        }

        if (!$this->uninstallTab()) {
            return false;
        }

        if (!$this->deleteConfig()) {
            return false;
        }

        return true;
    }

    protected function createDatabaseTable()
    {
        $sql = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'ns_abandoned_cart` (
            `id_abandoned_cart` INT(11) NOT NULL AUTO_INCREMENT,
            `id_cart` INT(11) NOT NULL,
            `id_customer` INT(11) NOT NULL,
            `date_add` DATETIME NOT NULL,
            PRIMARY KEY (`id_abandoned_cart`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8';
        return Db::getInstance()->execute($sql);
    }

    protected function dropDatabaseTable()
    {
        $sql = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ns_abandoned_cart`';
        return Db::getInstance()->execute($sql);
    }

    protected function installTab()
    {
        $tab = new Tab();
        $tab->active = 1;
        $tab->class_name = 'AdminAbandonedCart';
        $tab->name = array();
        foreach (Language::getLanguages(true) as $lang) {
            $tab->name[$lang['id_lang']] = 'Abandoned Cart';
        }
        $tab->id_parent = (int)Tab::getIdFromClassName('AdminParentOrders');
        $tab->module = $this->name;
        return $tab->add();
    }

    protected function uninstallTab()
    {
        $id_tab = (int)Tab::getIdFromClassName('AdminAbandonedCart');
        $tab = new Tab($id_tab);
        return $tab->delete();
    }

    protected function createConfig()
    {
        return Configuration::updateValue('NS_ACR_REMINDER_INTERVAL', 24);
    }

    protected function deleteConfig()
    {
        return Configuration::deleteByName('NS_ACR_REMINDER_INTERVAL');
    }

    public function getContent()
    {
        $output = null;

        if (Tools::isSubmit('submit' . $this->name)) {
            $this->postProcess();
            $output .= $this->displayConfirmation($this->l('Settings updated'));
        }
        
        $adminLink = $this->context->link->getAdminLink('AdminAbandonedCart');
        $output .= '<div class="panel">';
        $output .= '<h3>' . $this->l('Manage Abandoned Carts') . '</h3>';
        $output .= '<p>' . $this->l('Send reminder to customers so that they can finsih theire carts.') . '</p>';
        $output .= '<a href="' . $adminLink . '" class="btn btn-primary">' . $this->l('Go to Abandoned Cart Admin') . '</a>';
        $output .= '</div>';

        return $output . $this->renderForm();
    }

    protected function postProcess()
    {
        $reminder_interval = (int)Tools::getValue('NS_ACR_REMINDER_INTERVAL');
        Configuration::updateValue('NS_ACR_REMINDER_INTERVAL', $reminder_interval);
    }

    protected function renderForm()
    {
        $fields_form = [
            'form' => [
                'legend' => [
                    'title' => $this->l('Settings'),
                    'icon' => 'icon-cogs'
                ],
                'input' => [
                    [
                        'type' => 'text',
                        'label' => $this->l('Reminder Interval (hours)'),
                        'name' => 'NS_ACR_REMINDER_INTERVAL',
                        'class' => 'fixed-width-xs',
                        'suffix' => 'hours',
                        'desc' => $this->l('Set the reminder interval in hours.')
                    ],
                ],
                'submit' => [
                    'title' => $this->l('Save'),
                ]
            ]
        ];

        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submit' . $this->name;
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false) . '&configure=' . $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = [
            'fields_value' => [
                'NS_ACR_REMINDER_INTERVAL' => Tools::getValue('NS_ACR_REMINDER_INTERVAL', Configuration::get('NS_ACR_REMINDER_INTERVAL'))
            ],
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        ];

        return $helper->generateForm([$fields_form]);
    }

    public function hookActionCartSave($params)
    {
        /* Check if the cart is abandoned */
        $cart = $params['cart'];
        if ($cart->id_customer && !$cart->id_order) {
            $sql = 'SELECT * FROM `' . _DB_PREFIX_ . 'ns_abandoned_cart` WHERE `id_cart` = ' . (int)$cart->id;
            $result = Db::getInstance()->getRow($sql);
            if (!$result) {
                Db::getInstance()->insert('ns_abandoned_cart', [
                    'id_cart' => (int)$cart->id,
                    'id_customer' => (int)$cart->id_customer,
                    'date_add' => date('Y-m-d H:i:s')
                ]);
            }
        }
    }

    public function hookDisplayBackOfficeHeader($params)
    {
        // Include necessary JS/CSS for admin interface
    }
}
