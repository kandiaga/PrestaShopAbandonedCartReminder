<?php

class AdminAbandonedCartController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->table = 'ns_abandoned_cart';
        $this->className = 'AbandonedCart';
		$this->identifier='id_abandoned_cart';
        $this->allow_export = true;

        parent::__construct();

        $this->fields_list = [
            'id_abandoned_cart' => ['title' => $this->l('ID'), 'align' => 'center', 'class' => 'fixed-width-xs'],
            'id_cart' => ['title' => $this->l('Cart ID')],
            'id_customer' => ['title' => $this->l('Customer ID')],
            'date_add' => ['title' => $this->l('Date Added')],
        ];
		
		 $this->actions = ['delete','bulk_delete'];
		
		$this->bulk_actions = [
            'delete' => [
                'text' => $this->l('Delete selected'),
                'confirm' => $this->l('Delete selected items?'),
            ],
        ];
		
    }

    public function renderList()
    {
        return parent::renderList();
    }
	
	
    public function postProcess()
    {
        
		
		if(Tools::isSubmit('submitBulkdelete' . $this->table)) {
        $ticketIds = Tools::getValue($this->table . 'Box');

        if (!empty($ticketIds) && is_array($ticketIds)) {
            foreach ($ticketIds as $id_ticket) {
                $this->deleteItemCart($id_abandoned_cart);
            }
            $this->confirmations[] = $this->trans('Selected tickets and their related answers have been deleted successfully.', [], 'Admin.Notifications.Success');
        }
    }
		
		

        parent::postProcess();
    }
	
	
	public function deleteItemCart($id_abandoned_cart)
	{
		// Initialize database instance
		$db = Db::getInstance();
		
		$deleteTicketSql = 'DELETE FROM ' . _DB_PREFIX_ . 'ns_helpdesk_tickets WHERE id_abandoned_cart = ' . (int)$id_abandoned_cart;
		$db->execute($deleteTicketSql);
	}


	
	
	
}
