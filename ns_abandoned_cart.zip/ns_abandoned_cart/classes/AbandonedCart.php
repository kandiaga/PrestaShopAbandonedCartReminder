<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

class AbandonedCart extends ObjectModel
{
    public $id_cart;
    public $id_customer;
    public $id_shop;
    public $date_add;

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'ns_abandoned_cart',
        'primary' => 'id_abandoned_cart',
        'fields' => array(
            'id_cart' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true),
            'id_customer' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true),
            'id_shop' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true),
            'date_add' => array('type' => self::TYPE_DATE, 'validate' => 'isDate', 'required' => true),
        ),
    );

    public function __construct($id = null, $id_lang = null, $id_shop = null)
    {
        parent::__construct($id, $id_lang, $id_shop);
    }

    /**
     * Get abandoned carts
     *
     * @param int $days Number of days to consider a cart abandoned
     * @return array
     */
    public static function getAbandonedCarts($days = 1)
    {
        $sql = new DbQuery();
        $sql->select('ac.*');
        $sql->from('ns_abandoned_cart', 'ac');
        $sql->where('ac.date_add <= DATE_SUB(NOW(), INTERVAL '.(int)$days.' DAY)');
        $sql->where('ac.id_cart NOT IN (SELECT o.id_cart FROM '._DB_PREFIX_.'orders o)');
        
        return Db::getInstance()->executeS($sql);
    }

    /**
     * Send reminder emails for abandoned carts
     *
     * @param int $days Number of days to consider a cart abandoned
     */
    public static function sendReminderEmails($days = 1)
    {
        $abandonedCarts = self::getAbandonedCarts($days);
        foreach ($abandonedCarts as $cart) {
            $customer = new Customer($cart['id_customer']);
            $cartObj = new Cart($cart['id_cart']);
            
            /* Send email logic here*/
            Mail::Send(
                (int)Configuration::get('PS_LANG_DEFAULT'),
                'abandoned_cart_reminder',
                Mail::l('We miss you! Complete your purchase'),
                array('{customer_name}' => $customer->firstname, '{cart_link}' => Context::getContext()->link->getPageLink('order', true, null, "step=1&id_cart={$cartObj->id}")),
                $customer->email,
                $customer->firstname.' '.$customer->lastname,
                null, null, null, null, _PS_MAIL_DIR_, false, (int)$cart['id_shop']
            );
        }
    }
}
