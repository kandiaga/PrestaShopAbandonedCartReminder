<?php
require(dirname(__FILE__).'/../../config/config.inc.php');
require(dirname(__FILE__).'/../../init.php');

$interval = (int)Configuration::get('NS_ACR_REMINDER_INTERVAL');
$time_limit = date('Y-m-d H:i:s', strtotime("-$interval hours"));

$sql = 'SELECT ac.id_cart, ac.id_customer, c.email
        FROM `'._DB_PREFIX_.'ns_abandoned_cart` ac
        JOIN `'._DB_PREFIX_.'customer` c ON ac.id_customer = c.id_customer
        WHERE ac.date_add <= \'' . pSQL($time_limit) . '\'
        AND ac.id_cart NOT IN (SELECT id_cart FROM `' . _DB_PREFIX_ . 'orders`)';

$results = Db::getInstance()->executeS($sql);

foreach ($results as $result) {
    $id_cart = (int)$result['id_cart'];
    $id_customer = (int)$result['id_customer'];
    $customer_email = $result['email'];

    // Send email reminder
    $template_vars = [
        '{cart_link}' => Context::getContext()->link->getPageLink('order', true, null, "step=1&cart_id=$id_cart"),
        '{shop_name}' => Configuration::get('PS_SHOP_NAME')
    ];

    Mail::Send(
        (int)Context::getContext()->language->id,
        'abandoned_cart_reminder',
        Mail::l('We noticed you left something behind!', Context::getContext()->language->id),
        $template_vars,
        $customer_email,
        null,
        Configuration::get('PS_SHOP_EMAIL'),
        Configuration::get('PS_SHOP_NAME'),
        null,
        null,
        dirname(__FILE__).'/../mails/',
        false,
        (int)$id_customer
    );

    // Update the reminder sent status if necessary
    Db::getInstance()->delete('ns_abandoned_cart', 'id_cart = ' . $id_cart);
}
